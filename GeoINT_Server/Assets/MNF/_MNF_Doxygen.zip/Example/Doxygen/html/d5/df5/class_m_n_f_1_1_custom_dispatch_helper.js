var class_m_n_f_1_1_custom_dispatch_helper =
[
    [ "AllocMessage< TData >", "d5/df5/class_m_n_f_1_1_custom_dispatch_helper.html#a36b7c470eef7de68c37671f94ac0f643", null ],
    [ "AllocMessage< TTarget, TData >", "d5/df5/class_m_n_f_1_1_custom_dispatch_helper.html#a7790f0859ebc343cabc5e1dcce1f0a33", null ]
];