var _script_20___common_2_common_8cs =
[
    [ "MessageDispatchInfo", "d9/ded/struct_message_dispatch_info.html", "d9/ded/struct_message_dispatch_info" ],
    [ "ENUM_MESSAGE_TYPE", "d5/dd2/_script_20___common_2_common_8cs.html#a56e690b8c9b7816cb4d94e6c2dc24105", [
      [ "MESSAGE_TYPE_BINARY", "d5/dd2/_script_20___common_2_common_8cs.html#a56e690b8c9b7816cb4d94e6c2dc24105afcff4152b9c27527a0bd32e44a927b40", null ],
      [ "MESSAGE_TYPE_JSON", "d5/dd2/_script_20___common_2_common_8cs.html#a56e690b8c9b7816cb4d94e6c2dc24105a8cbcd13549a113b5826c1bd6f5a451b3", null ]
    ] ]
];