var class_m_n_f_1_1_message_1_1_binary_message_header =
[
    [ "messageID", "d5/d16/class_m_n_f_1_1_message_1_1_binary_message_header.html#ab6d105ebdea87a802c54f7ca9ecc204d", null ],
    [ "messageSize", "d5/d16/class_m_n_f_1_1_message_1_1_binary_message_header.html#a7dc67a4ce99968a43f9278c03bbbe6a4", null ]
];