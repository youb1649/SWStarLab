var class_m_n_f___common_1_1_custom_json_message_header =
[
    [ "messageID", "d5/dc1/class_m_n_f___common_1_1_custom_json_message_header.html#a5e16a30cf09ce9b3aeedc574de01c12a", null ],
    [ "messageSize", "d5/dc1/class_m_n_f___common_1_1_custom_json_message_header.html#a46defa9566202b41410b31b14dc0d703", null ]
];