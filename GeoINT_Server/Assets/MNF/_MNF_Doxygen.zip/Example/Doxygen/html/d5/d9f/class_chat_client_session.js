var class_chat_client_session =
[
    [ "OnConnectFail", "d5/d9f/class_chat_client_session.html#a57810d8c67572aff466f5f0d368d2d1f", null ],
    [ "OnConnectSuccess", "d5/d9f/class_chat_client_session.html#a534f264e1d95f0148c4e0bbb3aa3eb5b", null ],
    [ "OnDisconnect", "d5/d9f/class_chat_client_session.html#aef6f8ea6927555f8af961a02bf69c0a2", null ]
];