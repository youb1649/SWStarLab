var class_m_n_f___common_1_1_a_e_s_binary_message_header =
[
    [ "checksum1", "d5/d0d/class_m_n_f___common_1_1_a_e_s_binary_message_header.html#a85b887797269bff57a4a9345dfb3cdf6", null ],
    [ "checksum2", "d5/d0d/class_m_n_f___common_1_1_a_e_s_binary_message_header.html#acf3c33c7f817ea57fd9fd31acf8c410e", null ],
    [ "messageID", "d5/d0d/class_m_n_f___common_1_1_a_e_s_binary_message_header.html#af877300982ed268a9ffd502f51481d3a", null ],
    [ "messageSize", "d5/d0d/class_m_n_f___common_1_1_a_e_s_binary_message_header.html#a67001a826f8c8e5cefec30ee98336830", null ]
];