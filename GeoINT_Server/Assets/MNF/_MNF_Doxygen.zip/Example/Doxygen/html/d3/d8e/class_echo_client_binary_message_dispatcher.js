var class_echo_client_binary_message_dispatcher =
[
    [ "onSC_ECHO", "d3/d8e/class_echo_client_binary_message_dispatcher.html#aa5b5328d936fa218ecd0cec3aaba5e81", null ],
    [ "onSC_HEARTBEAT_REQ", "d3/d8e/class_echo_client_binary_message_dispatcher.html#aeab2fd8522fd052a1091a115041bc6ca", null ]
];