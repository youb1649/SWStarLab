var class_m_n_f_1_1_i_dispatch_helper =
[
    [ "IDispatchHelper", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#af02066b9c043faca098e473155b18d30", null ],
    [ "AllocMessage< TData >", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#accfabf1cb34f744781f0f96123100801", null ],
    [ "AllocMessage< TTarget, TData >", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a8115e8b782fbadc28004f277229ab570", null ],
    [ "CreateMessage< TTarget, TData >", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#ab322784ee134f11ac3f1010c3cb1e943", null ],
    [ "Init", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a63dd39187c31b50d8f4cec6351d8699f", null ],
    [ "OnInit", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a5ae1f458d34d0cf654e692bc513de46c", null ],
    [ "TryCreateMessage< TTarget, TData >", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a443f45a7681643298f8f96503c03c41e", null ],
    [ "TryGetMessageDispatch", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a70ff62d260ce7261eb7c470ad2b64f56", null ],
    [ "dispatchList", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#afd9ef61128c9586e7dcae25910419368", null ],
    [ "isInit", "d6/dc7/class_m_n_f_1_1_i_dispatch_helper.html#a1253bbf5a2e9144e9d86c0a6138602dd", null ]
];