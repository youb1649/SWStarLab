var _dispatch_info_8cs =
[
    [ "DispatchInfo", "d7/d4b/class_m_n_f_1_1_dispatch_info.html", "d7/d4b/class_m_n_f_1_1_dispatch_info" ],
    [ "onCustomDispatch< T >", "d6/d05/_dispatch_info_8cs.html#ad9cdf7d000346d3997d09e4167b8c824", null ],
    [ "onDispatch< T >", "d6/d05/_dispatch_info_8cs.html#a74b0bb80ca0e0a58e54ccbb49bbb7886", null ]
];