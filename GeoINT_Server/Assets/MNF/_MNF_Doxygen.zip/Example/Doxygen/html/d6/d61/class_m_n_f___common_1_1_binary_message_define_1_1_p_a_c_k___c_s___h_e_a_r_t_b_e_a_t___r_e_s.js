var class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___c_s___h_e_a_r_t_b_e_a_t___r_e_s =
[
    [ "PACK_CS_HEARTBEAT_RES", "d6/d61/class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___c_s___h_e_a_r_t_b_e_a_t___r_e_s.html#a6c06c2eae132f3525c13ab2a0316f655", null ],
    [ "tickCount", "d6/d61/class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___c_s___h_e_a_r_t_b_e_a_t___r_e_s.html#a089f2025e6e8b2b7ce9c80a720a554de", null ]
];