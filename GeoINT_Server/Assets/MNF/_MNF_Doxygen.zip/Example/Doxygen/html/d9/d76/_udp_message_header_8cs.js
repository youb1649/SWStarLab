var _udp_message_header_8cs =
[
    [ "UdpDatagramHeader", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html", "d9/d46/class_m_n_f_1_1_udp_datagram_header" ],
    [ "UdpMessageHeader", "d0/d6d/class_m_n_f_1_1_udp_message_header.html", "d0/d6d/class_m_n_f_1_1_udp_message_header" ],
    [ "UdpMessageInfo", "de/da3/class_m_n_f_1_1_udp_message_info.html", "de/da3/class_m_n_f_1_1_udp_message_info" ],
    [ "ENUM_UDP_CONTROL_FLAG", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecb", [
      [ "UDP_CONTROL_FLAG_UNKNOWN", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecbac9c323570b18f1c37ea4cd1e6b37be3c", null ],
      [ "UDP_CONTROL_FLAG_SYN", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecba08ea41a5eab1c222eaa38ee947c9b09c", null ],
      [ "UDP_CONTROL_FLAG_FIN", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecba80456ef837779ae19bb760720f70f0c4", null ],
      [ "UDP_CONTROL_FLAG_ACK", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecbae6f8410b4e0533e30090422f6a79247f", null ],
      [ "UDP_CONTROL_FLAG_PSH", "d9/d76/_udp_message_header_8cs.html#ac63db542abed91c7ef9900bc9890eecba0df8b44a8cc6e3271c6dcd95224660c4", null ]
    ] ],
    [ "ENUM_UDP_DATAGRAM_TYPE", "d9/d76/_udp_message_header_8cs.html#a8b7f01161a5cd67829b0eef6ea02cc67", [
      [ "UDP_DATAGRAM_TYPE_UNKNOWN", "d9/d76/_udp_message_header_8cs.html#a8b7f01161a5cd67829b0eef6ea02cc67af47c477861cd68468161c63c8ac9eead", null ],
      [ "UDP_DATAGRAM_TYPE_UNRELIABLE", "d9/d76/_udp_message_header_8cs.html#a8b7f01161a5cd67829b0eef6ea02cc67a4f90208212054a5b5c9e347fa3ddaa96", null ],
      [ "UDP_DATAGRAM_TYPE_RELIABLE", "d9/d76/_udp_message_header_8cs.html#a8b7f01161a5cd67829b0eef6ea02cc67ab7194dadeecce67d9d0d50b796ba5a92", null ]
    ] ]
];