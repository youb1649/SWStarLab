var struct_message_dispatch_info =
[
    [ "init", "d9/ded/struct_message_dispatch_info.html#a52635b15751db22d9aa6b49fe0a0dcd1", null ],
    [ "dispatchCount", "d9/ded/struct_message_dispatch_info.html#acdb2466c5c0c73ac4fb9fb17c21eea3e", null ],
    [ "dispatchSize", "d9/ded/struct_message_dispatch_info.html#aafd213a3d7c0506c6cf486629c73228e", null ],
    [ "totalDispatchCount", "d9/ded/struct_message_dispatch_info.html#a7693a817f7564698a4011d745fd3bf44", null ],
    [ "totalDispatchSize", "d9/ded/struct_message_dispatch_info.html#adb6ade8d61620b5dfca6460dddb64ebe", null ]
];