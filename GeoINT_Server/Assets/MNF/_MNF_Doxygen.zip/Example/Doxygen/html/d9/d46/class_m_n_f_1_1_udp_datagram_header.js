var class_m_n_f_1_1_udp_datagram_header =
[
    [ "UdpDatagramHeader", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a121f3e9b11a72ec21734c5b7356c0444", null ],
    [ "compare", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a6ac06cdb4e57006282536647ffce671f", null ],
    [ "getHeaderSize", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a0a42e8090479679a0866665922336fcf", null ],
    [ "getHeaderType", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a4315b5c4b44a4511a8b4a20c16f89906", null ],
    [ "initHeader", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#ab62f615bbf722e4af4db1fbfb0919ef4", null ],
    [ "setControlBit_ACK", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a12b9ba6ce702652f1221922861593877", null ],
    [ "setControlBit_PSH", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a4365d6642db8465adc6d1276fa965305", null ],
    [ "setReliable", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a22a1313df1b4dad23db61c5c6c332c6c", null ],
    [ "setUnreliable", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a3e9703496e8cf40955238ac6d23425a2", null ],
    [ "controlbit", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a0b86dfc28595dbbca626cea5af2f3db0", null ],
    [ "datagramSequence", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#afb0b195de3298e56ed8328faaccb65c4", null ],
    [ "datagramType", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a27c1f7f86294f4e2a512dee8f07aefac", null ],
    [ "emptyMessageHeader", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a65b18f640625b42577f29ec29d8e37e0", null ],
    [ "headerSize", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a06bf4f9011b5272698c8250ad5610192", null ],
    [ "sendSize", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a84e75b706679841de9d080d7c06f8309", null ],
    [ "sendTick", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a737f8da66d6580e304668824a49780e1", null ],
    [ "seqNumber", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a810954528c200ea6aa4926ae776c4df1", null ],
    [ "sessionUID", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#a923296650e0bac5a8a70958b3c8fbdfe", null ],
    [ "window", "d9/d46/class_m_n_f_1_1_udp_datagram_header.html#ae0faa09eda9c653e3e6b6a24ccb86191", null ]
];