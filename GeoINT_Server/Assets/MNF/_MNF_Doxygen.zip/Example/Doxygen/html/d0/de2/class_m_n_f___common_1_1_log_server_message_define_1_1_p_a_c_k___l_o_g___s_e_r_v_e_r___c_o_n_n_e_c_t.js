var class_m_n_f___common_1_1_log_server_message_define_1_1_p_a_c_k___l_o_g___s_e_r_v_e_r___c_o_n_n_e_c_t =
[
    [ "fromID", "d0/de2/class_m_n_f___common_1_1_log_server_message_define_1_1_p_a_c_k___l_o_g___s_e_r_v_e_r___c_o_n_n_e_c_t.html#a4166fcdb1edea07046ff604367f2c056", null ],
    [ "fromInfo", "d0/de2/class_m_n_f___common_1_1_log_server_message_define_1_1_p_a_c_k___l_o_g___s_e_r_v_e_r___c_o_n_n_e_c_t.html#a623ffee9d5e72569c8c381191dc42642", null ]
];