var class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___s_c___h_e_a_r_t_b_e_a_t___r_e_q =
[
    [ "PACK_SC_HEARTBEAT_REQ", "d0/d36/class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___s_c___h_e_a_r_t_b_e_a_t___r_e_q.html#a14d8424d1d077a30ebef7647f47dffd7", null ],
    [ "tickCount", "d0/d36/class_m_n_f___common_1_1_binary_message_define_1_1_p_a_c_k___s_c___h_e_a_r_t_b_e_a_t___r_e_q.html#a1c5d3961f027ba29365ac152532834a9", null ]
];