var class_chat_client_message_dispatcher =
[
    [ "onSC_BROADCAST_CHAT_MESSAGE", "d1/d8a/class_chat_client_message_dispatcher.html#a60a1f10b273fe91cbdc55453434be5ff", null ],
    [ "onSC_SEND_CHAT_MESSAGE", "d1/d8a/class_chat_client_message_dispatcher.html#a71d1424484ff16bea0034f993913e4af", null ]
];