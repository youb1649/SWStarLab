var class_m_n_f_1_1_send_message =
[
    [ "SendMessage", "d1/d4c/class_m_n_f_1_1_send_message.html#afd75f46e7a57dafbd806d4eae9857223", null ],
    [ "ID", "d1/d4c/class_m_n_f_1_1_send_message.html#ae7c91115930521688d30ab6fd19f7788", null ],
    [ "Message", "d1/d4c/class_m_n_f_1_1_send_message.html#af70a3b6ee39150103e6737bb26bc0d3a", null ],
    [ "Type", "d1/d4c/class_m_n_f_1_1_send_message.html#ab9d11f49721e86549d9cd1ff59c678df", null ]
];