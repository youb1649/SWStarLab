var class_binary_message_header =
[
    [ "checkSum", "d1/df2/class_binary_message_header.html#a13e46b563abf0f9670bd60f230e6e2d9", null ],
    [ "messageID", "d1/df2/class_binary_message_header.html#a4af81f98fe0070dd8da5ac4db69540af", null ],
    [ "messageSize", "d1/df2/class_binary_message_header.html#aab7dab83e762f2774153a5b8b0f4b2ef", null ],
    [ "sequence", "d1/df2/class_binary_message_header.html#a009a3978963d7c0706546d99667a8bbc", null ]
];