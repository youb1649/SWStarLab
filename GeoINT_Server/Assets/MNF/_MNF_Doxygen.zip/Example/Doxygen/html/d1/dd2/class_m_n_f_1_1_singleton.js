var class_m_n_f_1_1_singleton =
[
    [ "OnDestroy", "d1/dd2/class_m_n_f_1_1_singleton.html#a282c1a40c9bbda62c179720fedf34971", null ],
    [ "_instance", "d1/dd2/class_m_n_f_1_1_singleton.html#a442b912fa6357724a52f1a6e5b5e08ed", null ],
    [ "_lock", "d1/dd2/class_m_n_f_1_1_singleton.html#ae0bf7020694a616d08d25221c56e1340", null ],
    [ "applicationIsQuitting", "d1/dd2/class_m_n_f_1_1_singleton.html#a2a9b800a1ba695baf720851976a0fb5d", null ],
    [ "Instance", "d1/dd2/class_m_n_f_1_1_singleton.html#ac6a849fefb501f9c60d335f738a4bcd5", null ]
];