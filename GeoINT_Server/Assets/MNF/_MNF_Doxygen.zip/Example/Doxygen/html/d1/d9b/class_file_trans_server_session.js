var class_file_trans_server_session =
[
    [ "OnAccept", "d1/d9b/class_file_trans_server_session.html#ac39c0e9968f2accdae6a5b1745df480d", null ],
    [ "OnDisconnect", "d1/d9b/class_file_trans_server_session.html#a32af15d07e61aecbfcdfb762b9630578", null ]
];