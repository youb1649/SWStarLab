var class_m_n_f_1_1_message_1_1_serializer =
[
    [ "Serializer", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a0b6f53fbbc9ab50abb636738ac0e777c", null ],
    [ "_Serialize< T >", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a00cb74caa22455e5285ca70b32f2ec73", null ],
    [ "GetSerializedBuffer", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a0414616e4bc53cc95698e554f6c2e7ed", null ],
    [ "GetSerializedBuffer", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a665dba2f225c0eb317ed38bbebefab02", null ],
    [ "Serialize< T >", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#adfb52f6e8564f063e964b9c56e2713eb", null ],
    [ "HeaderType", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a5f2ac59417d05f14ef19bd859c3f8a76", null ],
    [ "MaxMessageBufferSize", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a4ebc1f63538a998b70f5887ac5c801a6", null ],
    [ "MessageBuffer", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#ac9c161222ca2638e20de681244d63fb0", null ],
    [ "MessageHeader", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a2108f3e6814445495e9ccedffb3225bd", null ],
    [ "SerializedHeaderSize", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a103359a52099b9ba6627e82360c2cb2c", null ],
    [ "SerializedLength", "d2/d61/class_m_n_f_1_1_message_1_1_serializer.html#a16241659b91bbe0d5a4d2b0cdc533040", null ]
];