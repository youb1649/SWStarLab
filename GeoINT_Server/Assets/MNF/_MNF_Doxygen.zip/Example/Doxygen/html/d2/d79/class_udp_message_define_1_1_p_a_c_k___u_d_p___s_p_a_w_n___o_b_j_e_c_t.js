var class_udp_message_define_1_1_p_a_c_k___u_d_p___s_p_a_w_n___o_b_j_e_c_t =
[
    [ "PACK_UDP_SPAWN_OBJECT", "d2/d79/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_p_a_w_n___o_b_j_e_c_t.html#ad5742985283ea872443cce2d5619a15f", null ],
    [ "position", "d2/d79/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_p_a_w_n___o_b_j_e_c_t.html#a2f8d25659369f56aff901a05169415f1", null ],
    [ "rotation", "d2/d79/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_p_a_w_n___o_b_j_e_c_t.html#aa73b00b14ccd585ddf2f0ea7c53a3618", null ]
];