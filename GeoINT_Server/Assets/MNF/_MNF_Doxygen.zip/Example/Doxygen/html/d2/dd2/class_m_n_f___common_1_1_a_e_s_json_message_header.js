var class_m_n_f___common_1_1_a_e_s_json_message_header =
[
    [ "checksum1", "d2/dd2/class_m_n_f___common_1_1_a_e_s_json_message_header.html#a4cc0a92ab4d340b981344743d8917c5b", null ],
    [ "checksum2", "d2/dd2/class_m_n_f___common_1_1_a_e_s_json_message_header.html#a997733b6529b3fb68a92e0ac37d21dfb", null ],
    [ "messageID", "d2/dd2/class_m_n_f___common_1_1_a_e_s_json_message_header.html#ad182bd23e0ea2c8fbfaa37922a920ff2", null ],
    [ "messageSize", "d2/dd2/class_m_n_f___common_1_1_a_e_s_json_message_header.html#a4edde27a57f979e7a423907088462747", null ]
];