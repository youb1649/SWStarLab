var class_chat_server_message_dispatcher =
[
    [ "onCS_BROADCAST_CHAT_MESSAGE", "da/d1a/class_chat_server_message_dispatcher.html#a95b7411d87e3978b5c0741e7f9173b64", null ],
    [ "onCS_SEND_CHAT_MESSAGE", "da/d1a/class_chat_server_message_dispatcher.html#ad34cb467942723bc5b9212f629a05f41", null ]
];