var class_m_n_f_1_1_message_1_1_json_message_header =
[
    [ "messageID", "d4/d4e/class_m_n_f_1_1_message_1_1_json_message_header.html#af09561f716991dd4695074402d9ab9fc", null ],
    [ "messageSize", "d4/d4e/class_m_n_f_1_1_message_1_1_json_message_header.html#aed1f349570a9c5e758181d34f77565f4", null ]
];