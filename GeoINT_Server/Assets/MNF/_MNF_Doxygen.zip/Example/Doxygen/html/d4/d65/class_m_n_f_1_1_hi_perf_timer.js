var class_m_n_f_1_1_hi_perf_timer =
[
    [ "HiPerfTimer", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#a21a7412efc5c9563b40a3f67acceda26", null ],
    [ "QueryPerformanceCounter", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#a5e4f510b19a04fd8d26ca209afd584e3", null ],
    [ "QueryPerformanceFrequency", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#aee7347404c8505b7b6340bc9cbfbb7fa", null ],
    [ "Start", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#aaaa9a4bea7dfef4ad86efc88cff0536e", null ],
    [ "Stop", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#a9a803d729bbdaea981f717f73fbaae4c", null ],
    [ "freq", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#ab3bb59a6e9328f8fb95e146e504575c5", null ],
    [ "startTime", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#a78b0adef2a1869a4ae81b96f6f597355", null ],
    [ "stopTime", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#ac4c7fcea4ae4df3cee3cf4f8b20a7418", null ],
    [ "Duration", "d4/d65/class_m_n_f_1_1_hi_perf_timer.html#a6591f6a37a47fb6537c672c66c71a064", null ]
];