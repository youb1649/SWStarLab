var class_file_trans_server_button_trigger =
[
    [ "Awake", "d4/d88/class_file_trans_server_button_trigger.html#a151bd4b7b83209b683aba3ed51439b66", null ],
    [ "OnApplicationQuit", "d4/d88/class_file_trans_server_button_trigger.html#a44af15018c289ed1fd5089bdbc77f27f", null ],
    [ "OnDestroy", "d4/d88/class_file_trans_server_button_trigger.html#ab7338d69723f1e22960ac2803362c50d", null ],
    [ "OnLoadImage", "d4/d88/class_file_trans_server_button_trigger.html#a2991c636ef0f1fce7d6a73385dbe3fff", null ],
    [ "OnSendImage", "d4/d88/class_file_trans_server_button_trigger.html#acdb4f21028a89b9b583cfa66099e15c8", null ],
    [ "OnStartServer", "d4/d88/class_file_trans_server_button_trigger.html#ad37e5d8bdbf3404b4bb6ab821a2c4bb5", null ],
    [ "Release", "d4/d88/class_file_trans_server_button_trigger.html#a5618ce602168c60afccda05484d129af", null ],
    [ "RunSendImage", "d4/d88/class_file_trans_server_button_trigger.html#a68df1f0c700f191b69061cbcd58c5b8d", null ],
    [ "Update", "d4/d88/class_file_trans_server_button_trigger.html#a20e81bcece0e1aab7390d1bae081f23f", null ],
    [ "loadBinaryImage", "d4/d88/class_file_trans_server_button_trigger.html#aee3e451f11c714baa3585f60bcc5df05", null ],
    [ "loadFileName", "d4/d88/class_file_trans_server_button_trigger.html#a30754d0a65316658b5e77a11c358a939", null ],
    [ "rawImage", "d4/d88/class_file_trans_server_button_trigger.html#a18ce88d7bc5d3454a2cc26c57ed91f5b", null ],
    [ "sendButton", "d4/d88/class_file_trans_server_button_trigger.html#add7666948950d57737d093c2125a1c8b", null ],
    [ "serverIP", "d4/d88/class_file_trans_server_button_trigger.html#a6b1f546785ce548e5d740fefd44df5eb", null ],
    [ "serverPort", "d4/d88/class_file_trans_server_button_trigger.html#aa5ecc9fbc2391b7a1286e7c3bafa09bf", null ]
];