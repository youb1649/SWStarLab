var class_m_n_f_1_1_i_p_address_extensions =
[
    [ "GetBroadcastAddress", "d4/df6/class_m_n_f_1_1_i_p_address_extensions.html#acaeab72a12eb728a49c100efc8a4e78b", null ],
    [ "GetNetworkAddress", "d4/df6/class_m_n_f_1_1_i_p_address_extensions.html#a47cb32753c288ddb4c8be5b7e1f3b314", null ],
    [ "IsInSameSubnet", "d4/df6/class_m_n_f_1_1_i_p_address_extensions.html#a31d3c4d1df0e1934e0f8c2b9c6f22c17", null ]
];