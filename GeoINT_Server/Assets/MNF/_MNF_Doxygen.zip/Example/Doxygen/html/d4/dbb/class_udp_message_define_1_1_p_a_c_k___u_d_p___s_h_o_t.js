var class_udp_message_define_1_1_p_a_c_k___u_d_p___s_h_o_t =
[
    [ "PACK_UDP_SHOT", "d4/dbb/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_h_o_t.html#a2f3179f132e803482fa369c5727b110e", null ],
    [ "position", "d4/dbb/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_h_o_t.html#ab7be0f562df0b6f90961576dc56ef495", null ],
    [ "rotation", "d4/dbb/class_udp_message_define_1_1_p_a_c_k___u_d_p___s_h_o_t.html#af78e667552d7b622ffdc4c77031f7626", null ]
];