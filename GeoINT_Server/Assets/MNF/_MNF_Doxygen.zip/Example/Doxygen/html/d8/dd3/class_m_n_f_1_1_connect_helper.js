var class_m_n_f_1_1_connect_helper =
[
    [ "_Connect< TSession, TDispatcher >", "d8/dd3/class_m_n_f_1_1_connect_helper.html#a34f53ab6e90dcb229a5d4bc287fb0bc9", null ],
    [ "AsyncConnect< TSession, TDispatcher >", "d8/dd3/class_m_n_f_1_1_connect_helper.html#a36538849fad7a399d6d6392f84b6e38e", null ]
];