var class_m_n_f___common_1_1_file_trans_message_define =
[
    [ "PACK_SC_FILE_TRANS_END", "de/d93/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___e_n_d.html", "de/d93/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___e_n_d" ],
    [ "PACK_SC_FILE_TRANS_SEND", "de/d44/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___s_e_n_d.html", "de/d44/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___s_e_n_d" ],
    [ "PACK_SC_FILE_TRANS_START", "da/de2/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___s_t_a_r_t.html", "da/de2/class_m_n_f___common_1_1_file_trans_message_define_1_1_p_a_c_k___s_c___f_i_l_e___t_r_a_n_s___s_t_a_r_t" ],
    [ "ENUM_CS_", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a9b8f19b3724509ca4efe0e2e758a35f5", null ],
    [ "ENUM_SC_", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a296d77d78e536923ea7ba6c8a38dc25f", [
      [ "SC_FILE_TRANS_START", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a296d77d78e536923ea7ba6c8a38dc25fa59cc928cb01abf8b901c19724a6ae1c7", null ],
      [ "SC_FILE_TRANS_SEND", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a296d77d78e536923ea7ba6c8a38dc25fada617ab079ef2b247ef60229870589cc", null ],
      [ "SC_FILE_TRANS_END", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a296d77d78e536923ea7ba6c8a38dc25fa481cf5fe33780595296a14239e965bfe", null ]
    ] ],
    [ "MaxSize", "d8/dff/class_m_n_f___common_1_1_file_trans_message_define.html#a0526d7f867a930840f706655aebde765", null ]
];