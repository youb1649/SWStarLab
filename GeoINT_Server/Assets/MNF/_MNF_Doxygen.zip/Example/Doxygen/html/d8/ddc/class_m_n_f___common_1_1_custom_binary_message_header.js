var class_m_n_f___common_1_1_custom_binary_message_header =
[
    [ "messageID", "d8/ddc/class_m_n_f___common_1_1_custom_binary_message_header.html#a30c425397ceebc2302c522d5883c5946", null ],
    [ "messageSize", "d8/ddc/class_m_n_f___common_1_1_custom_binary_message_header.html#af1d8a72f42f6be63959cb17c0113f956", null ]
];