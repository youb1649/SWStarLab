var class_input_field_server_i_p =
[
    [ "Start", "d8/dda/class_input_field_server_i_p.html#a046a4ad187a04e4899dc9db047ef099c", null ],
    [ "SubmitIP", "d8/dda/class_input_field_server_i_p.html#a5e0a29f5b11e7acee23f4d6c626a7f91", null ]
];