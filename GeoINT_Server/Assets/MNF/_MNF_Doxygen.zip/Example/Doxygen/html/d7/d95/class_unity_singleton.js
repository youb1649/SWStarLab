var class_unity_singleton =
[
    [ "OnDestroy", "d7/d95/class_unity_singleton.html#a12cce066a27fb08f34141caac3fc5e0c", null ],
    [ "_instance", "d7/d95/class_unity_singleton.html#ae66091d944308c7f264398027f630614", null ],
    [ "_lock", "d7/d95/class_unity_singleton.html#a299d621cbbd6e9a50b33bbb7f7dd9478", null ],
    [ "applicationIsQuitting", "d7/d95/class_unity_singleton.html#af627ddf659b9903d81fa87640eb098e2", null ],
    [ "Instance", "d7/d95/class_unity_singleton.html#af8e77adbc77cf28a6eeb3f5ed1f91093", null ]
];