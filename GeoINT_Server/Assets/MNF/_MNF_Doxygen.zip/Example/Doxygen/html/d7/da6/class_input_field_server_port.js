var class_input_field_server_port =
[
    [ "Start", "d7/da6/class_input_field_server_port.html#a3ed764d2042850b7502ec76bd5d6aabc", null ],
    [ "SubmitPort", "d7/da6/class_input_field_server_port.html#ab6c2cc9e5ca68fb0a7a1d068cc21642f", null ]
];