var class_m_n_f___common_1_1_crypt_json_message_header =
[
    [ "checksum1", "d7/dd8/class_m_n_f___common_1_1_crypt_json_message_header.html#a09ff0224f531ac1b5b5a18f8db6369bb", null ],
    [ "checksum2", "d7/dd8/class_m_n_f___common_1_1_crypt_json_message_header.html#a97e3d6b8a187ef5bcd99bba3768aa110", null ],
    [ "messageID", "d7/dd8/class_m_n_f___common_1_1_crypt_json_message_header.html#abf47028f8bd1cb69f4619a3a0213d2e3", null ],
    [ "messageSize", "d7/dd8/class_m_n_f___common_1_1_crypt_json_message_header.html#afc46d3708512fed693f9e11812d24906", null ]
];