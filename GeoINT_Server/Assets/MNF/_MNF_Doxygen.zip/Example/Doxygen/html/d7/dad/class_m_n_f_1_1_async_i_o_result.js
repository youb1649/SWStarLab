var class_m_n_f_1_1_async_i_o_result =
[
    [ "serializer", "d7/dad/class_m_n_f_1_1_async_i_o_result.html#a50ff1bc26dfee70cc39b8aa15e9a5d0f", null ],
    [ "session", "d7/dad/class_m_n_f_1_1_async_i_o_result.html#a6b836e55335d31b7a703dc7cf0b0ed23", null ]
];